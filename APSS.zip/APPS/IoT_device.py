import random
from APPS import server, RC, ECC
from APPS.parameter import str_int


def register(nd, dev, key, r, sp):
    device_id = random.sample(dev, nd)  # number of devices

    # device password
    device_pswd, k = [], []
    for i in range(len(device_id)):
        k.append(random.getrandbits(4))  # public key (4 bit random)
        Xr_id_k = str_int(device_id[i]) ^ k[i]  # exor device id with public key
        device_pswd.append(int(r * Xr_id_k))

    # registration
    P_ = server.dev_register(device_id, device_pswd, sp)
    RC.dv_verify(P_, device_id, device_pswd, sp, nd)

    return device_pswd, k, device_id


def authenticate1(Did, K, Dpd, r):
    am1, am2 = [], []
    for ii in range(len(Did)):
        am1.append(ECC.encryption(Did[ii], K[ii]))
        am2.append(hash(str(Dpd[ii]) + str(r) + str(am1[ii])))
    return am1, am2


def authenticate2(Did, K, Dpd, ik, Vm1, Vm2):
    Vm1_, Vm2_ = [], Vm2
    for ii in range(len(Did)):
        Vm1_.append(hash(Did[ii] + str(ik[0])))

    return Vm1_, Vm2_


def verify(Ps, d_id, ik):
    g = []
    for i in range(len(d_id)):
        g.append(Ps ^ hash(d_id[i] + str(ik[i])))
    return g
