import random, numpy as np
from APPS import RC, ECC, IoT_device
from APPS.parameter import str_int


# server register
def register(s_id, s_psd):
    ks_, S = RC.register(s_id, s_psd)
    ks = RC.reg(ks_)
    RC.rsu_verify(ks, ks_)
    return ks, S


# device register
def dev_register(d_id, d_pswd, S):
    return RC.dev_register(d_id, d_pswd, S)


# generate key
def key_generate(ks, device_psd, S, Spd, data):
    # secret key
    print("Key generation.")
    Sy = []
    for i in range(len(device_psd)):
        h_p_s = hash(str(device_psd[i]) + str(S))  # hash (concatenated device password & security parameter)
        Sy.append(np.abs(h_p_s ^ ks))

    # code key
    x = np.abs(str_int(Spd) * hash(str(ks) + str(S)))
    A = (x ** 2) + (2 * x) + 1  # polynomial

    Ck = A * np.array(Sy)

    print("Authentication.Please wait.")
    Dk = []
    data = [data[0]]
    for ii in range(len(Ck)):
        cipher_data = []
        Dk.append(str(Ck[ii]) + str(S))
        for i in range(len(data)):
            e_data = []
            for j in range(len(data[i])):
                e_data.append(ECC.encryption(data[i][j], Ck[ii]))
            cipher_data.append(np.array(e_data))

    return Dk, Sy, Ck, cipher_data


def authenticate(Did, K, Dpd, r, am1, am2, sy, s):
    ek = np.array(sy) % r
    am1_, am2_ = am1, []
    for ii in range(len(Did)):
        am2_.append(hash(str(Dpd[ii]) + str(r) + str(am1[ii])))

    Vm1, Vm2, ik = [], [], []
    Ps = 0
    if am1 == am1_ and am2 == am2_:
        for ii in range(len(Did)):
            ik.append(random.getrandbits(4))  # private key of device
            Vm1.append(hash(Did[ii] + str(ik[ii])))
            Vm2.append(Vm1[ii] ^ str_int(str(ECC.encryption(str(Dpd[ii]), K[ii]))))

            Vm1_, Vm2_ = IoT_device.authenticate2(Did, K, Dpd, ik, Vm1, Vm2)
            for i in range(len(Vm1)):
                if Vm1[i] == Vm1_[i]:
                    pass

            for i in range(len(Did)):
                Ps = hash(ek[i] + (str_int(Did[i]) * s))
    return Ps, ik


def verify(Ps, d_id, ik, g):
    count = 0
    for i in range(len(d_id)):
        g_ = Ps ^ hash(d_id[i] + str(ik[i]))
        if g[i] == g_:
            count += 1
    if count == len(d_id):
        return 1
    else:
        return 0

