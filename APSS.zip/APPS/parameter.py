import numpy as np


def str_int(data):
    converted = 0
    for i in range(len(data)):
        converted += ord(data[i])
    return converted


def distance(data_1, data_2):
    D = []
    for i in range(len(data_1)):
        D.append(np.abs(str_int(str(data_2[i]))-str_int(str(data_1[i]))))   # difference after spoofing
    return D


# distance between points
def pt_distance(p1, p2):
    dist = np.sqrt((np.square(p2[0] - p1[0])) + (np.square(p2[1] - p1[1])))
    return dist

