import random
from APPS.parameter import str_int


# server registration
def register(s_id, s_psd):
    s = random.randint(1, 10)  # security parameter
    return (str_int(s_id) * hash(s_psd + str(s))), s  # Ks (private key for server)


# verify server registration
def rsu_verify(ks, ks_):
    if ks == ks_: print("\t>> Server is registered.")


# device registration
def dev_register(Did, Dpswd, s):
    P = []
    for i in range(len(Did)):
        P.append(str_int(Did[i]) ^ hash(str(Dpswd[i]) + str(s)))  # P value for each device
    return P


def dv_verify(P_, id, pswd, s, nd):
    P = dev_register(id, pswd, s)
    count = 0
    for i in range(len(P)):
        if P_[i] == P[i]:
            count += 1  # increment count in each user verification
    if count == nd:
        print("\t>> IoT devices are registered.")


def reg(ks):
    return ks
