import csv, numpy as np
import Cloudsim.Run
from APPS import server, IoT_device, parameter
import random
import time, tracemalloc

ds = '40 KB'  # Select data size
n_devices = 10  # Number of devices
k_size = '128'  # Key length
tracemalloc.start()
start = time.time()


# get server for the device
def get_server():
    r = random.randint(1, 5)
    id = 'server' + str(r)
    pswd = id + '123'
    return id, pswd


# password spoofing
def spoof(data):
    spoofed = []
    for i in range(len(data)):
        r = "" + str(int(random.random() * 100))
        spoofed.append(str(data[i]) + r)  # Spoofing process
    return spoofed


# Detection rate
def detection_rate(user, n):
    Actual = []
    for i in range(n):
        Actual.append(user[i])  # device password
    pswd_sf = spoof(Actual)  # password
    dist = parameter.distance(Actual, pswd_sf)
    Th = (np.average(dist) + max(dist)) / 2

    dr = 0
    for i in range(len(dist)):
        if dist[i] < Th: dr += 1
    return dr / n


def read_data(filename):
    datas = []
    with open(filename, 'rt')as f:
        content = csv.reader(f)  # read csv content
        for rows in content:  # row of data
            tem = []
            for cols in rows:  # attributes in each row
                tem.append(cols)  # add value to tem array
            datas.append(tem)  # add 1 row of array value to dataset
    return datas


data = Cloudsim.Run.cloud_sim("dataset/Data.csv", ds)  # data

device_id = np.array(read_data("APPS/device.csv")).flatten().tolist()  # read existing device details

# server registration
s_ID, s_pswd = get_server()  # server ID & password
ks, Sp = server.register(s_ID, s_pswd)  # server registration

# device registration
r = random.random()  # ran[0, 1]
device_psd, K, dv_ID = IoT_device.register(n_devices, device_id, k_size, r, Sp)

# Key Generation phase
dk, sy, Ck, cipher_data = server.key_generate(ks, device_psd, Sp, s_pswd, data)

am1, am2 = IoT_device.authenticate1(dv_ID, Ck, device_psd, r)
Ps_, ik = server.authenticate(dv_ID, Ck, device_psd, r, am1, am2, sy, Sp)

g = IoT_device.verify(Ps_, dv_ID, ik)
V = server.verify(Ps_, dv_ID, ik, g)

if V == 1:
    print(">>> completed: ")

t = (time.time() - start)  # time calculation
current, peak = tracemalloc.get_traced_memory()
m = (current / 10 ** 6)  # Memory => current in byte (converted to MB)

dr = (detection_rate(device_psd, n_devices))
