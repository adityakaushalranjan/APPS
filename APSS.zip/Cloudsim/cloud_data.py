import csv, numpy as np

# reading data
def read_dataset(dataset, ds):
    datas = []
    n = int(int(ds[0])/2)   # to make user specified data size
    for i in range(n):
        with open(dataset, 'rt')as f:
            content = csv.reader(f)     # read csv content
            for rows in content:        # row of data
                tem = []
                for cols in rows:       # attributes in each row
                    tem.append(cols)    # add value to tem array
                datas.append(tem)       # add 1 row of array value to dataset
    return datas

def cloud_compute(dataset, data_size):
    input_data = read_dataset(dataset, data_size)

    data, target = [], []
    for i in range(len(input_data)):        # each row of data
        tem = []                            # tem array to store row of data
        for j in range(len(input_data[i])): # attributes in each row
            if input_data[i][j] == "?":
                input_data[i][j] = str(0.0)      # replace missing values by 0
            tem.append(input_data[i][j])     # datas
        data.append(tem)                    # append each row
    return np.array(data)
